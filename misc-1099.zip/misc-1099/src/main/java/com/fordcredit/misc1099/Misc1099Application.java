package com.fordcredit.misc1099;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Misc1099Application {

	public static void main(String[] args) {
		SpringApplication.run(Misc1099Application.class, args);
	}

}
