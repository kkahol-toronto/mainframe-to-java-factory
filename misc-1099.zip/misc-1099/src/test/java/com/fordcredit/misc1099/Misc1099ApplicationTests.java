package com.fordcredit.misc1099;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Misc1099ApplicationTests {

	@Test
	void contextLoads() {
	}

}
